import React from 'react';

interface VanguardLogoProps {
  className?: string;
  height?: number | string;
  showText?: boolean;
}

export const VanguardLogo: React.FC<VanguardLogoProps> = ({
  className = 'h-8 w-auto',
  height = 32,
  showText = true,
}) => {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox={showText ? '0 0 540 120' : '0 0 120 120'}
      className={className}
      style={{ height, width: 'auto' }}
      aria-label="Vanguard Studio"
      role="img"
    >
      <defs>
        <linearGradient id="vgGold" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#FDE047" />
          <stop offset="45%" stopColor="#F59E0B" />
          <stop offset="100%" stopColor="#D97706" />
        </linearGradient>
        <linearGradient id="vgGoldText" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#FFFFFF" />
          <stop offset="40%" stopColor="#FDE047" />
          <stop offset="100%" stopColor="#F59E0B" />
        </linearGradient>
      </defs>

      {/* Hexagonal Isometric Circuit Cube Mark */}
      <g transform="translate(10, 10) scale(0.166667)">
        <polygon
          points="300,20 542,160 542,440 300,580 58,440 58,160"
          fill="#0A0B0E"
          stroke="url(#vgGold)"
          strokeWidth="16"
          strokeLinejoin="round"
        />
        <g stroke="url(#vgGold)" strokeWidth="7" strokeLinecap="round" strokeLinejoin="round" fill="none">
          <line x1="300" y1="185" x2="300" y2="70" />
          <line x1="300" y1="415" x2="300" y2="530" />
          <polyline points="250,214 200,185 200,118" />
          <polyline points="350,214 400,185 400,118" />
          <polyline points="200.4,280 150,280 150,185 102,185" />
          <polyline points="399.6,280 450,280 450,185 498,185" />
          <line x1="200.4" y1="310" x2="100" y2="310" />
          <line x1="399.6" y1="310" x2="500" y2="310" />
          <line x1="200.4" y1="345" x2="110" y2="412" />
          <line x1="399.6" y1="345" x2="490" y2="412" />
          <polyline points="250,386 200,415 200,482" />
          <polyline points="350,386 400,415 400,482" />
          <polygon points="300,185 399.6,242.5 300,300 200.4,242.5" fill="#0A0B0E" />
          <polygon points="200.4,242.5 300,300 300,415 200.4,357.5" fill="#0A0B0E" />
          <polygon points="300,300 399.6,242.5 399.6,357.5 300,415" fill="#0A0B0E" />
        </g>
        <g stroke="url(#vgGold)" strokeWidth="6" fill="#0A0B0E">
          <circle cx="300" cy="70" r="14" />
          <circle cx="300" cy="530" r="14" />
          <circle cx="200" cy="118" r="13" />
          <circle cx="400" cy="118" r="13" />
          <circle cx="102" cy="185" r="13" />
          <circle cx="498" cy="185" r="13" />
          <circle cx="100" cy="310" r="13" />
          <circle cx="500" cy="310" r="13" />
          <circle cx="110" cy="412" r="13" />
          <circle cx="490" cy="412" r="13" />
          <circle cx="200" cy="482" r="13" />
          <circle cx="400" cy="482" r="13" />
          <circle cx="300" cy="300" r="12" />
          <circle cx="300" cy="185" r="12" />
          <circle cx="300" cy="415" r="12" />
          <circle cx="200.4" cy="242.5" r="12" />
          <circle cx="399.6" cy="242.5" r="12" />
          <circle cx="200.4" cy="357.5" r="12" />
          <circle cx="399.6" cy="357.5" r="12" />
        </g>
      </g>

      {/* Typography: VANGUARD STUDIO */}
      {showText && (
        <g transform="translate(130, 0)">
          <text
            x="0"
            y="58"
            fill="url(#vgGoldText)"
            fontFamily="'Roboto', 'Montserrat', 'Inter', -apple-system, sans-serif"
            fontSize="34"
            fontWeight="800"
            letterSpacing="5"
          >
            VANGUARD
          </text>
          <g transform="translate(0, 84)">
            <line x1="0" y1="-8" x2="32" y2="-8" stroke="#F59E0B" strokeWidth="2.5" strokeLinecap="round" />
            <text
              x="42"
              y="-1"
              fill="#FDE047"
              fontFamily="'Roboto', 'Montserrat', 'Inter', -apple-system, sans-serif"
              fontSize="16"
              fontWeight="700"
              letterSpacing="8"
            >
              STUDIO
            </text>
            <line x1="168" y1="-8" x2="280" y2="-8" stroke="#F59E0B" strokeWidth="1.5" strokeDasharray="4 3" opacity="0.6" />
          </g>
          <text
            x="0"
            y="106"
            fill="#A3A3A3"
            fontFamily="'Roboto', 'Montserrat', 'Inter', -apple-system, sans-serif"
            fontSize="9"
            fontWeight="600"
            letterSpacing="4"
          >
            DIGITAL WEB SOLUTIONS
          </text>
        </g>
      )}
    </svg>
  );
};
